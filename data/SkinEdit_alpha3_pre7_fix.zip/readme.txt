Minecraft Skin Editor alpha 3 pre 7
	by: Patrik Swedman
	(preview feature uses external code, the recomended library is made by Notch)
	Additional credit can be found in the program under Help -> About.

 Compadabillity:
 ---------------
This version has been developed on Windows 7 64-bit Ultimate.
This version has been tested on Windows 7 64-bit Ultimate and Ubuntu 10.4 64-bit with SunJDK6
Older versions of this program has been tested under Ubuntu 9.10 64-bit, Ubuntu 9.10 32-bit and Max OSX snow leopard (with java 6).

The program is Java based and should work on any computer that supports Java 6.

 Start the program:
 ------------------
Just double click the .jar 
If it opens as a compressed folder or your operating system says it can't open the file then right click the file and see if you can open with Java or use the Launch.bat file.
If you can't open with Java download the latest java runtime from http://www.java.com/


 Known bugs:
 -----------
The tabs that indicate color selection won't display the selected color if the tab itself is selected.

 F.A.Q.:
 ------ -
Q: My previewer won't install correctly.
A: First make sure the URL in the popup telling you to download the previewer is working by browsing to it in a webbrowser. If it is broken check the opening post on the forum for an alternative.
   If the link is working but the previewer won't install try installing SkinEdit to a folder on your desktop, it should be allowed to write files there and this is quite a common problem.

Q: I get a message about the previewer being corrupt.
A: Just delete the skintest2.jar file and restart SkinEdit. It should download a new one by itself!

Q: I run Windows and when I try to launch the program I can see a black box for a second.
A: You've told Windows to open java files in java.exe which won't work. Try to reinstall java, if that doesn't work 

Q: I run Windows and when I try to launch the program it opens as a archive (in WinRAR for example).
A: You need to reassociate the program with java. Right click the file, select open with and select Choose default program. Select Java runtime and click ok. Please note browsing to java.exe won't work.
   If that doesn't work try launching with the batch file included with the program. (Launch.bat)

 Instructions:
 -------------
Click a tool to use it. Most tools can be customized if you open the Tool Settings window.

If you liked the controls in the old SkinEdit versions you should use the Multitool, it works in a similar way and you can configurate it in the settings.

A lot of other stuff can be found in the menu bar, and a lot of those tools have keyboard shortcuts.
If you find it hard to remember the controlls you can open a window which displayes the controlls under the help menu.

To use a custom background first put it in the "backgroudnds" folder. If it doesn't exist you can create it. Note that it must be in the same place as MCSkinEdit.jar.
Now, you can select your custom background from Settings > Background image > filename.png
The size of the image doesn't matter, the program will change size after the image. The program has support for the wrong aspect ratio but not only does it look funny but officially it is not supported.

To add more parts for PartPicker just put them in the "parts" folder.

 Changelog:
 ----------
alpha 3 pre 6 -> alpha 3 pre 7
	Fixed a lot of problems with Java 5 (better mac compatibility).
	Fixed undo/redo.
	General optimizations.
	Removed "outside color" option, it was not really needed.
	Fixed a lot of problems with the settings, all settings should now work as normal.
	Settings should now save between uses. For example the background image is saved.
	Moved the tool settings to their own window which can be opened by the settigns button.
	Improved previewer errormessages and made them stop asking you to report them.
	Added a "Add behind image" to the previewer. This means parts will be added behind already added things.
	Imrpoved the offline mode to be more stable, might still have minor problems.
	Fixed problem where you got the "java.lang.UnsupportedOperationException: Desktop API is not supported on the current platform" on some computers.
	Added a multitool which makes the controls kinda like in alpha 3 pre 5 and earlier except you can configurate it!
	Better error messages when saving and loading failes.
	Improved the welcome message slightly.
	Readded the brushsize option to the pen tool.
	Readded the batch file which has been updated to work better.

alpha 3 pre 5 -> alpha 3 pre 6
	Fixed a problem with starting up a new HTTP server everytime PartPicker was launched
	Added fallback if HTTP server would fail to start (blocked by firewall etc.). In case HTTP server failes the old mincraft.net connection will be used.
	Fixed a linux problem where Partpicker parts and background images had to be in the user dir.
	Fixed a problem with running under vista with parantal controlls without administrator (thanks to niel for helping me to test)
	Fixed a problem with the way the background was loaded (thanks to niel for helping me to test)
	Added some more options for advanced users into settings. You'll find some info in advanced.txt in the jar file
	Fixed bug where some skins created with older versions of SkinEdit or external programs wouldn't undo on transparent areas.
	Added Java 5 support (Java 6 still recomended). This should make it work on all macs again.
	Fixed bug with the PartPicker previewer where the image wouldn't be updated at launch.
	Fixed bug where PartPicker ignored previewer settings.
	Added a line draw tool to draw lines between points.
	Improved launch stabillity. Should be a lot less common that SkinEdit freezes during launch.
	Fixed PartPicker window launching in the upper corner of the screen (it will now place itself relative to the main SkinEdit window).
	Fixed a bug where selecting "New image" tool took much longer then it should have done (not sure if this was in pre 5)
	Added a item previewer into PartPicker.
	Added more settings into PartPicker.
	Changed the way PartPicker adds images. They will now be added to the top of the list.
	Fixed various misspellings in the program.
	Added more parts to the PartPicker.
	Added all people who made backgrounds and parts to the in-program credit list.
	Added a warning for people using a java older than Java 6.
	Added a welcome message telling people about the known bugs in this unfinished version.

alpha 3 pre 4 -> alpha 3 pre 5
	Added a feedback dialog for when the program is downloading skintest2.jar (the previewer)
	Improved error handling. All errors will now be displayed in a window. (This may require some tweeking)
	Added a extension to the previewer. It will now display your skin as it would look in-game. You can turn this off in settings
	Added a screenshot button to create a screenshot from the preview
	Fixed a bug with the Add Noice tool that slowed it down quite a lot and spammed text to the console (if started from console)
	Fixed the bug that the filename wouldn't update when you loaded a new file or used save as. You will now save to the correct file.
	Lowered the strength on the shading tools. Remember you can hold down CTRL to use increased strength.
	Added the PartPicker. Press CTRL + P or go to Edit > PartPicker to open it. It allows you to easilly add details to your skin.
	Added a hack which makes the previewer work even when you do not have a Internet connection. (This speeds up startup time)
	Settings save to settings.xml (Might be found in working dir, program dir or in <user dir>/.skinedit
	Fixed misspelled "Add Noice" to "Add Noise"

alpha 3 pre 3 -> alpha 3 pre 4
	Fixed shading on transparent
	Fixed middle mouse button not working
	Added a extra powerful dodge and burn
	Added a simple way of using your own backgrounds by placing them in the "backgrounds" folder
	Added a noice tool. This is supposed to be a quick-and-dirty way to get BASIC shading, you should still use burn and dodge to make sure everything looks right.

alpha 3 pre 2 -> alpha 3 pre 3
	Changed the way the program handles the image
	Added flood fill
	Added burn and dodge
	Added another shortcut for copy color
	Added a window that displays some of the controlls (you can see some shortcuts in the menu)
	Added a internal crash handler which removed the usage for Launch.bat

alpha 2 -> alpha 3 pre 2
	Remade the design
	Realtime preview
	Undo and redo system
	Change brushsize
	New file handling system, doesn't ask you where to save a file you edited

alpha 1 -> alpha 2
	Added preview functionallity (requires a library made by Notch which will be downloaded)
	If your filename when you try to save the file doesn't end with .png it will get .png added
	Added color copy
	Added a reset shortcut